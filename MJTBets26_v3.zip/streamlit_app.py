from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import streamlit as st

from football_api import FootballDataClient, FootballDataError
from predictor import build_prediction
from statistics import completed_before, parse_utc


st.set_page_config(
    page_title="MJ Bets 26",
    page_icon="⚽",
    layout="centered",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
    .block-container{max-width:780px;padding-top:1rem;padding-bottom:3rem}
    .match-card{border:1px solid rgba(128,128,128,.28);border-radius:18px;
      padding:17px;margin:13px 0;background:rgba(128,128,128,.055)}
    .competition{font-size:.82rem;opacity:.7;margin-bottom:8px}
    .fixture{font-size:1.16rem;font-weight:750;line-height:1.35}
    .kickoff{font-size:.88rem;opacity:.72;margin-top:4px}
    .score{font-size:2.1rem;font-weight:850;margin:13px 0 3px}
    .pick{font-size:1rem;font-weight:700;margin-bottom:12px}
    .quality{font-size:.78rem;opacity:.72;margin:9px 0 0}
    .stat-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
    .stat{padding:10px;border-radius:11px;background:rgba(128,128,128,.10)}
    .stat-label{font-size:.73rem;opacity:.68}
    .stat-value{font-size:1rem;font-weight:720}
    </style>
    """,
    unsafe_allow_html=True,
)


def secret(name: str) -> str:
    try:
        return str(st.secrets[name]).strip()
    except Exception:
        return ""


@st.cache_data(ttl=900, show_spinner=False)
def get_fixtures(api_key: str, selected_date: date):
    return FootballDataClient(api_key).matches_for_date(selected_date)


@st.cache_data(ttl=3600, show_spinner=False)
def get_competition_data(
    api_key: str,
    competition_identifier: str,
    season_year: int | None,
):
    client = FootballDataClient(api_key)
    matches = client.competition_matches(competition_identifier, season_year)

    try:
        standings = client.standings(competition_identifier, season_year)
    except FootballDataError:
        standings = []

    return matches, standings


def uk_time(utc_value: str) -> str:
    try:
        return parse_utc(utc_value).astimezone(
            ZoneInfo("Europe/London")
        ).strftime("%H:%M UK")
    except (ValueError, TypeError):
        return "Time unavailable"


def competition_identifier(fixture: dict) -> str:
    competition = fixture.get("competition", {})
    return str(competition.get("code") or competition.get("id"))


def season_year(fixture: dict) -> int | None:
    start_date = fixture.get("season", {}).get("startDate")
    if not start_date:
        return None
    try:
        return int(start_date[:4])
    except (TypeError, ValueError):
        return None


st.title("⚽ MJ Bets 26")
st.caption("Data-driven football predictions built from recent match results")

api_key = secret("FOOTBALL_DATA_API_KEY")

with st.sidebar:
    st.header("Settings")
    selected_date = st.date_input(
        "Fixture date",
        value=date.today(),
        min_value=date.today() - timedelta(days=3),
        max_value=date.today() + timedelta(days=10),
    )
    minimum_confidence = st.slider(
        "Minimum result confidence",
        30,
        75,
        40,
        1,
    )
    minimum_data_quality = st.slider(
        "Minimum data quality",
        0,
        100,
        20,
        5,
    )
    maximum_fixtures = st.slider(
        "Maximum fixtures analysed",
        3,
        20,
        10,
        1,
    )
    include_postponed = st.toggle("Include postponed fixtures", value=False)

    if st.button("Refresh data", use_container_width=True):
        get_fixtures.clear()
        get_competition_data.clear()
        st.rerun()

    st.warning(
        "Predictions are statistical estimates, not guaranteed outcomes. "
        "Never chase losses and only gamble what you can afford to lose."
    )

if not api_key:
    st.error("Add your Football-Data.org key in Streamlit Secrets.")
    st.code('FOOTBALL_DATA_API_KEY = "your-api-key"', language="toml")
    st.stop()

try:
    fixtures = get_fixtures(api_key, selected_date)
except FootballDataError as exc:
    st.error(str(exc))
    st.stop()

if not include_postponed:
    fixtures = [
        item for item in fixtures
        if item.get("status") not in {"POSTPONED", "CANCELLED", "SUSPENDED"}
    ]

fixtures = fixtures[:maximum_fixtures]

if not fixtures:
    st.info(f"No supported fixtures found for {selected_date:%d %B %Y}.")
    st.stop()

competition_cache: dict[tuple[str, int | None], tuple[list, list]] = {}
predictions = []
errors = []

with st.spinner("Analysing real form and league data…"):
    for fixture in fixtures:
        identifier = competition_identifier(fixture)
        season = season_year(fixture)
        cache_key = (identifier, season)

        try:
            if cache_key not in competition_cache:
                competition_cache[cache_key] = get_competition_data(
                    api_key,
                    identifier,
                    season,
                )

            season_matches, standings = competition_cache[cache_key]
            kickoff = parse_utc(fixture.get("utcDate", ""))
            history = completed_before(season_matches, kickoff)
            prediction = build_prediction(fixture, history, standings)

            if prediction.result_confidence < minimum_confidence:
                continue
            if prediction.data_quality < minimum_data_quality:
                continue

            predictions.append((fixture, prediction))
        except (FootballDataError, ValueError) as exc:
            errors.append(f"{identifier}: {exc}")

if not predictions:
    st.info(
        "No fixtures meet your confidence and data-quality filters. "
        "Lower the sliders in Settings."
    )
    if errors:
        with st.expander("Data-source messages"):
            for message in sorted(set(errors)):
                st.write(message)
    st.stop()

predictions.sort(
    key=lambda item: (
        item[1].result_confidence,
        item[1].data_quality,
    ),
    reverse=True,
)

m1, m2, m3 = st.columns(3)
m1.metric("Fixtures", len(predictions))
m2.metric("Best", f"{predictions[0][1].result_confidence:.1f}%")
m3.metric(
    "Average",
    f"{sum(p.result_confidence for _, p in predictions) / len(predictions):.1f}%",
)

best_fixture, best_prediction = predictions[0]
st.subheader("⭐ Best-rated selection")
st.write(
    f"**{best_fixture['homeTeam']['name']} v "
    f"{best_fixture['awayTeam']['name']} — "
    f"{best_prediction.result_label} "
    f"({best_prediction.result_confidence:.1f}%)**"
)

st.subheader(f"Predictions for {selected_date:%d %B}")

for fixture, prediction in predictions:
    home = fixture.get("homeTeam", {}).get("name", "Home team")
    away = fixture.get("awayTeam", {}).get("name", "Away team")
    competition = fixture.get("competition", {}).get("name", "Competition")
    status = fixture.get("status", "").replace("_", " ").title()

    st.markdown(
        f"""
        <div class="match-card">
          <div class="competition">{competition}</div>
          <div class="fixture">{home} v {away}</div>
          <div class="kickoff">{uk_time(fixture.get('utcDate', ''))} · {status}</div>
          <div class="score">{prediction.score}</div>
          <div class="pick">{prediction.result_label} ·
            {prediction.result_confidence:.1f}% result probability</div>
          <div class="stat-grid">
            <div class="stat"><div class="stat-label">Home / Draw / Away</div>
              <div class="stat-value">{prediction.home_win:.0f}% /
              {prediction.draw:.0f}% / {prediction.away_win:.0f}%</div></div>
            <div class="stat"><div class="stat-label">Expected goals</div>
              <div class="stat-value">{prediction.home_xg:.2f}–{prediction.away_xg:.2f}</div></div>
            <div class="stat"><div class="stat-label">Over 2.5 goals</div>
              <div class="stat-value">{prediction.over_25:.1f}%</div></div>
            <div class="stat"><div class="stat-label">Both teams score</div>
              <div class="stat-value">{prediction.btts:.1f}%</div></div>
            <div class="stat"><div class="stat-label">Exact-score chance</div>
              <div class="stat-value">{prediction.exact_score_probability:.1f}%</div></div>
            <div class="stat"><div class="stat-label">Data quality</div>
              <div class="stat-value">{prediction.data_quality}%</div></div>
          </div>
          <div class="quality">Model inputs: recent results, home/away form,
          standings and available head-to-head matches.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.expander(f"Why the model chose {prediction.result_label.lower()}"):
        for reason in prediction.explanation:
            st.write(f"• {reason}")

if errors:
    with st.expander("Some competitions could not be fully analysed"):
        for message in sorted(set(errors)):
            st.write(message)

st.caption(
    "MJ Bets 26 v3 uses completed matches available from Football-Data.org. "
    "Coverage depends on your API subscription and the competition. "
    "Result probability is not the probability of the displayed exact score."
)
