# MJ Bets 26 v3

A mobile-first Streamlit football prediction dashboard.

## What v3 uses

- Recent completed matches
- Home and away form
- Goals scored and conceded
- Current league standings when available
- Head-to-head meetings within the available season data
- A Poisson score model

## Install

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Streamlit secret

Keep the key in Streamlit Community Cloud **Secrets**, not in GitHub:

```toml
FOOTBALL_DATA_API_KEY = "your-key"
```

## Files to replace in GitHub

Upload all files from this package to the repository root. Replace the existing
`streamlit_app.py` and `requirements.txt`.

Do not upload a real `.streamlit/secrets.toml` file.

## Important

Predictions are estimates. API coverage varies by plan and competition. The app
caches calls and fetches competition data once per competition to reduce API use.
